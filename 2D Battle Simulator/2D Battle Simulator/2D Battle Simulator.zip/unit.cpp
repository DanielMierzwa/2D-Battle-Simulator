#include "unit.h"
using namespace sf;

Unit::Unit(unitPattern unitData, float tposX, float tposY, std::string tteam) : hitbox(unitData.size), vectorFunctions(0.0, 0.0, 0.0) {
    posX = tposX;
    posY = tposY;
    size = unitData.size;
    team = tteam;
    hitbox.setPosition(Vector2f(posX-size,posY-size));
    if (team == "bad")
        hitbox.setFillColor(Color(255, 0, 127));
    else
        hitbox.setFillColor(Color(0, 204, 0));
}
void Unit::Update(Status gameStatus, std::vector<Unit> units) {
    if (gameStatus == Status::running) {
        float minDistance = 100000;
        int minIndex = -1;
        float distance = 0;
        //std::vector<Unit> badUnits;
        if (units.size() > 0) {
            for (int i = 0; i < units.size(); i++) {
                if (units[i].team != this->team) {
                    distance = vectorFunctions.checkDistance(units[i].posX,units[i].posY,this->posX,this->posY);
                   // badUnits.append(units[i]);
                    if (distance < minDistance) {
                        minDistance = distance;
                        minIndex = i;
                    }
                }
                
                
                
            }
            if (minIndex == -1) {
                battleFinished = true;
            }
            else{
                if(minDistance>this->size+units[minIndex].size)
                addVector(1, vectorFunctions.checkDirection(this->posX, this->posY,units[minIndex].posX, units[minIndex].posY), 0.01);
            }
        }
        

        //wykonanie wektor�w
        float pomPosX = posX;
        float pomPosY = posY;
        if (vectors.size() > 0)
        {
            for (int i = 0; i < vectors.size(); i++) {
                posX += vectors[i].move.x;
                posY += vectors[i].move.y;
                vectors[i].duration -= 1;

                // Sprawdzenie, czy duration wynosi 0 i usuni�cie wektora
                if (vectors[i].duration == 0) {
                    vectors.erase(vectors.begin() + i);
                    i--; // Decrementowanie indeksu, aby nie pomin�� nast�pnego elementu po usuni�ciu
                }
            }
            direction = vectorFunctions.checkDirection(pomPosX, pomPosY, posX, posY);
            hitbox.setPosition(Vector2f(posX - size, posY - size));
        }
        
    }
}
void Unit::render(RenderWindow& win) {
    win.draw(hitbox);
}
void Unit::addVector(int tduration, float x, float y) {
    vectors.push_back(UnitVector(tduration, x, y));
}