#include "unitVector.h"
UnitVector::UnitVector(int tduration, float tdirection, float force){
	duration = tduration;
	direction = tdirection;
	direction = (float)((int)direction % 360);
	if (direction < 0){
		direction += 360;
	}
	float sinus=sin(direction * 3.14159 / 180);
	float cosinus = cos(direction * 3.14159 / 180);
	move.x = sinus *force;
	move.y = cosinus * force;
}
float UnitVector::checkDistance(float posX1, float posY1, float posX2, float posY2) {
	float a = abs(posX1 - posX2);
	float b = abs(posY1 - posY2);
	return sqrt(a * a + b * b);
}
//float UnitVector::checkDirection(float posX1, float posY1, float posX2, float posY2) {
//	float dY = posY1 - posY2;
//	float dX = posX1 - posX2;
//	float sin = dY / checkDistance(posX1, posY1, posX2, posY2);
//	float tdirection = asin(sin) * 180 / 3.14159;
//	if (dY > 0 && dX < 0)
//		tdirection += 90;
//	if (dY <= 0 && dX <= 0)
//		tdirection =0-tdirection;
//	if (dY > 0 && dX > 0)
//		tdirection = 0 - tdirection - 90;
//	return tdirection;
//}
//float UnitVector::checkDirection(float x1, float y1, float x2, float y2) {
//    // Oblicz r�nice wsp�rz�dnych
//    float dx = x2 - x1;
//    float dy = y2 - y1;
//
//    // Oblicz k�t w radianach
//    float k�tRadiany = atan2(dy, dx);
//
//    // Przekszta�� k�t na stopnie
//    float k�tStopnie = k�tRadiany * 180.0 / 3.141592653589793;
//
//    // Dopasowanie k�ta do przedzia�u [0, 360), poniewa� k�t 0 to d�,
//    // a ro�nie przeciwnie do wskaz�wek zegara
//    k�tStopnie -= 180.0;
//
//    return k�tStopnie;
//}
//double calculateDirection(const Point& p1, const Point& p2) {
//	// Obliczanie r�nic wsp�rz�dnych
//	double dx = p2.x - p1.x;
//	double dy = p2.y - p1.y;
//
//	// Obliczanie k�ta za pomoc� atan2 (kierunek wektora w radianach)
//	return atan2(dy, dx);  // zwr�ci k�t w radianach
//}

float UnitVector::checkDirection(float posX1, float posY1, float posX2, float posY2) {
	float dx = posX2 - posX1;
	float dy = posY2 - posY1;
	// Przyk�adowe punkty


	// Obliczanie kierunku wektora
	float angle = atan2(dy, dx);


	// Konwertowanie k�ta na stopnie (opcjonalnie)
	float angleInDegrees = angle * 180 / 3.14159;
	if (dx < 0)
		angleInDegrees += 180;

	return angleInDegrees;
}