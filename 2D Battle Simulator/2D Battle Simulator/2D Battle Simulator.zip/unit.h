#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include "unitPattern.h"
#include "status.h"
#include "unitVector.h"
class Unit
{

	private:
		
		
		UnitVector vectorFunctions;
		

	public:
		Unit(unitPattern unitData,float tposX,float tposY, std::string tteam);
		void Update(Status gameStatus, std::vector<Unit> units);
		void render(sf::RenderWindow& win);//funkcja rysuj�ca przycisk
		float posX;//pozycja jednostki
		float posY;
		float size;
		float direction;
		bool battleFinished = false;
		std::vector<UnitVector> vectors;
		sf::CircleShape hitbox;//deklaracja hitboxy jednostki
		std::string team;
		void addVector(int tduration, float x, float y);
};

