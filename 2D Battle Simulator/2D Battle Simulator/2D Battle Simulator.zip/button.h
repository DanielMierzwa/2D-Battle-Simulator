#pragma once
#include <iostream>
#include<SFML/Graphics.hpp>
class Button
{
private:
	
	sf::RectangleShape hitbox;//przycisk


public:
	Button(float tposX, float tposY, float sizeX, float sizeY, std::string tname,std::string tpanelName,bool checkbox);
	std::string name;
	std::string panelName;
	bool checkClick(sf::Vector2f mousePos);//funkcja obs�uguj�ca klikni�cie w przycisk
	void render(sf::RenderWindow& win);//funkcja rysuj�ca przycisk
	void resetButton();// do odklikiwania przycisku
	void clickButton();// do klikania przycisku
	bool isActive;//czy przycisk jest aktywny
	bool checkbox;//typ przycisku: checkbox lub zwyk�y
	bool release;//czy puszczono przycisk
};

