﻿//#include <SFML/Graphics.hpp>
#include "game.h"
using namespace sf;
int main() {
    int windowWidth = 1280;
    int windowHeight = 800;
    RenderWindow window(VideoMode(windowWidth, windowHeight), "2D Battle Simulator",Style::Resize | Style::Close);
    Game game(window);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        game.update(event);  // Aktualizacja logiki
        game.render();  // Renderowanie
    }

    return 0;
}
//notatki:
//znajdywanie kierunków
// dodanie prędkości do unitPattern
//zadawanie obrażeń
// dodanie damage do unitPattern
//dawanie wktorów od kolizji