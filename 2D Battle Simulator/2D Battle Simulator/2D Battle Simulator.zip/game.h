#ifndef GAME_H
#define GAME_H

#include <SFML/Graphics.hpp>
#include <vector>
#include <iostream>
#include <cmath>
#include <fstream>
#include <ctime>
#include "unit.h"
#include "button.h"
#include "unitPattern.h"




class Game {
private:
    sf::RenderWindow& window;  // Referencja do okna
    sf::RectangleShape panel;    // Panel UI
    std::vector<Unit> units;    //lista jednostek na planszy
    std::vector<Button> buttons;//lista przycisk�w 
    std::string log;//zmienna przechowuj�ca log
    std::string errors;//zmienna na wszystkie errory
    int time[2];
    Status gameStatus;
    unitPattern unitsPatterns[3];//wzorce jednostek do kopiowania
    int activePattern;//indeks jednostki do skopiowania
    bool activeSet;//czy obecnie mozna stawia� nowe jednostki
    int tick;
    int previousTick;
    sf::CircleShape blueprint;//wska�nik miejsca do postawienia jednostki
    //dane blueprintu
    float size;

    //funkcje pomocnicze:
    int findButtonByName(std::string name);//funkcja do znajdywania przycisku po nazwie, zwraca index z tablicy
    bool canSet(sf::Vector2f mousePos);//funkcja do sprawdzenia czy mo�na postawi� jednostk�
    float distance(float posX1, float posY1, float posX2, float posY2);//funckja do obliczania odleg�o�ci
    void disactivePanel(std::string panelName);

public:
    Game(sf::RenderWindow& win);
    void update(sf::Event event);  // Aktualizacja logiki gry
    void render();  // Renderowanie gry
};

#endif // GAME_H
