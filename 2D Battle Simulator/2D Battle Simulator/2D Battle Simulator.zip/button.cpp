#include "button.h"
using namespace sf;
Button::Button(float tposX, float tposY, float sizeX, float sizeY, std::string tname, std::string tpanelName, bool tcheckbox): hitbox(Vector2f(sizeX,sizeY)) {
	hitbox.setPosition(tposX, tposY);
	name = tname;
	isActive = false;
	release = true;
	checkbox = tcheckbox;
	panelName = tpanelName;
}
bool Button::checkClick(Vector2f mousePos) {
	if ((checkbox==1 && !isActive) || !checkbox) {
		if (hitbox.getGlobalBounds().contains(mousePos))
			return true;
		else
			return false;
	}
	
}
void Button::render(RenderWindow& win) {
	if (!release)
		hitbox.setFillColor(Color::Blue);
	else
		hitbox.setFillColor(Color::White);
	win.draw(hitbox);
}
void Button::resetButton() {
	isActive = false;
	release = true;
}
void Button::clickButton() {
	isActive = true;
	release = false;
}
