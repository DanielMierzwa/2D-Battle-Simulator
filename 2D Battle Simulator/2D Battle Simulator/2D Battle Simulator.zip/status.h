#pragma once
enum Status { running, setting };