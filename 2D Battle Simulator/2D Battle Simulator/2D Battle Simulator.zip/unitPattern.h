#include <string>
#pragma once
struct unitPattern {
	std::string typeName;
	float size;
};
