#include "game.h"
using namespace sf;
Game::Game(RenderWindow& win) : window(win) ,panel(Vector2f(window.getSize().x, (window.getSize().y*0.2f) ) ),blueprint(20.0f){
    //inicjalizacja panelu
    panel.setPosition(0.0f, 0.0f);
    panel.setFillColor(Color::Magenta);
    buttons.push_back(Button(10.0,10.0,200.0,50.0,"rycerz","przyciski_stawiania", true));
    buttons.push_back(Button(220.0, 10.0, 200.0, 50.0, "lucznik", "przyciski_stawiania", true));
    buttons.push_back(Button(430.0, 10.0, 200.0, 50.0, "lucznik2", "przyciski_stawiania", true));
    buttons.push_back(Button(640.0, 10.0, 200.0, 50.0, "lucznik3", "przyciski_stawiania", true));

    buttons.push_back(Button(1220, 10.0, 50.0, 50.0, "play", "przyciski_uruchamiania", false));

    //definicja wzor�w jednostek
    //defincja rycerza
    unitsPatterns[0].size = 20.0f;
    unitsPatterns[0].typeName = "rycerz";
    //defincija �ucznika
    unitsPatterns[1].size = 18.0f;
    unitsPatterns[1].typeName = "lucznik";

    previousTick = 0;
    tick = 0;//resetowanie tick�w
    time[0] = int(std::time(nullptr));//pobieranie czasu na poczatku
    activeSet = false;
    gameStatus = Status::setting;//domy�lny tryb to stawianie jednostek
    size = 20.0f;
    activePattern = 0;
}

void Game::update(Event event) {

    log = "";
    // Tu mo�na doda� logik� gry, np. poruszanie obiektami
    log="\n\n========tick:" +  std::to_string(tick) +"\n"; // nag��wek logu
    time[1] = int(std::time(nullptr));//pobieranie aktualnego czasu
    log += "FPS:"+std::to_string(previousTick/(time[1]-time[0]+0.000001));
    if (time[1] - time[0] > 5) {
        time[1] = time[0];
        previousTick = tick;
    }

    Vector2i tempMousePos = Mouse::getPosition(window); // pobiera pozycj� myszy
    Vector2f mousePos = window.mapPixelToCoords(tempMousePos);
    log += "mouse pos: " + std::to_string(mousePos.x) + "," + std::to_string(mousePos.y) + "\n";
    log += "active unit setting: " + std::to_string(activeSet) + "\n";
    log += "game status: " + std::to_string(gameStatus) + "\n";

    //obs�uga wska�nika
    blueprint.setPosition(Vector2f(mousePos.x-size,mousePos.y-size));
    blueprint.setRadius(size);
    if (canSet(mousePos)) {
        if (mousePos.x > window.getSize().x / 2)
            blueprint.setFillColor(Color(255, 30, 127));
        else
            blueprint.setFillColor(Color(0, 234, 0));
    }
    else {
        blueprint.setFillColor(Color::Red);
    }
    
    // obs�uga event�w
    if (event.type == Event::MouseButtonPressed) { // gdy klikni�to mysz�
        
        if (activeSet == true && canSet(mousePos)) {//stawianie jednostki, jesli stawianie jest aktywne i jednostka z niczym nie koliduje
            std::string team;
            if (mousePos.x < window.getSize().x / 2)
                team = "good";
            else
                team = "bad";
            units.push_back(Unit(unitsPatterns[activePattern], mousePos.x, mousePos.y, team));//dodaje jednostke do listy
            units[units.size() - 1].addVector(100,-90,0);
            activeSet = false;
            disactivePanel("przyciski_stawiania");
            
        }

        
        for (int i = 0; i < buttons.size(); i++) {//p�tla obs�uguj�ca klikni�cia w guziki
            //sprawdza czy kliknieto przycisk
            if (buttons[i].checkClick(mousePos)) {
                if (buttons[i].release) {
                    disactivePanel(buttons[i].panelName);
                    buttons[i].clickButton();
                }
                else {
                    buttons[i].isActive = false;
                }

            }

            if (gameStatus == Status::setting) {
                
                
                //przyciski do stawiania jednostek
                if (buttons[i].name == "rycerz") {
                    if (buttons[i].isActive) {
                    
                        activeSet = true;
                        activePattern = 0;
                        size = unitsPatterns[activePattern].size;
                    }
                }
                if (buttons[i].name == "lucznik") {
                    if (buttons[i].isActive) {
                        activeSet = true;
                        activePattern = 1;
                        size = unitsPatterns[activePattern].size;
                    
                    }
                }
            }
                if (buttons[i].name == "play") {
                    if (buttons[i].isActive) {
                        if (gameStatus == Status::setting)
                        {
                            gameStatus = Status::running;
                        }
                        else
                            gameStatus = Status::setting;

                    }
                }
            
        }
    }
    for (int i = 0; i < buttons.size(); i++) {//odskakiwanie przycisk�w "nie checkbox�w"
        if (!buttons[i].checkbox)
            if (!sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                buttons[i].resetButton();
            }
                
    }

    tick++;

    //logika bitwy
    log += "\nUnits:";
    for (int i = 0; i < units.size(); i++) {
        units[i].Update(gameStatus,units);
        log += "\nteam: "+units[i].team + " | direction: " + std::to_string(units[i].vectors[0].direction);
    }
}

void Game::render() {
    window.clear(sf::Color::Black); // Czyszczenie ekranu
    
    for (int i = 0; i < units.size(); i++) {//p�tla do rysowania jednostek
        units[i].render(window);
    }
    if (activeSet)//jesli jest aktywne stawianie wy�wietl blueprint
        window.draw(blueprint);
    
    log += "\nButtons:\n";//nag��wek sekcji logu
    window.draw(this->panel); 
        for (int i = 0; i < buttons.size(); i++) {
            if(buttons[i].panelName=="przyciski_stawiania" && gameStatus == Status::setting)
                buttons[i].render(window);
            if(buttons[i].panelName == "przyciski_uruchamiania")
                buttons[i].render(window);
            log += buttons[i].name + " | active: " + (buttons[i].isActive ? "true" : "false") + " | checkbox: "+ (buttons[i].checkbox ? "true" : "false") + " | release: " + (buttons[i].release ? "true" : "false") + "\n";
        }

    
    std::cout << log;//wyswietlenie logu
    //zapisanie error�w do p�niejszej analizy
    std::ofstream outFile("errors.txt");
    if (outFile.is_open()) {
        // Zapisujemy zmienn� do pliku
        outFile << errors << std::endl;  // Zapisujemy tekst do pliku
        outFile.close();  // Zamykamy plik po zapisaniu
    }
    else {
        std::cerr << "Nie uda�o si� otworzy� pliku!" << std::endl;
    }
    log += "\n\nERRORS:" + errors;
    window.display();               // Wy�wietlenie zawarto�ci okna
}

//funkcje pomocnicze
int Game::findButtonByName(std::string name) {
    for (int i = 0; i < buttons.size(); i++) {
        if (buttons[i].name == name) {
            std::cout << "\nname:"<<name;
            return i;
        }
        
   }
    errors+= "\n" + std::to_string(tick) + ":(ERROR)Nie znaleziono przycisku o nazwie : " + name ;
        return 0;
}

bool Game::canSet(Vector2f mousePos) {
    if (panel.getGlobalBounds().contains(mousePos))//sprawdza kolizje z panelem UI
        return false;
    for (int i = 0; i < units.size(); i++) {//sprawdza kolizje z innymi jednostkami
        if (units[i].hitbox.getRadius()+size > distance(mousePos.x, mousePos.y, units[i].posX, units[i].posY))
            return false;
    }
    return true;
}

float Game::distance(float posX1, float posY1, float posX2, float posY2) {
    float a = abs(posX1 - posX2);
    float b = abs(posY1 - posY2);
    return sqrt(a * a + b * b);
}

void Game::disactivePanel(std::string panelName) {
    for (int i = 0; i < buttons.size(); i++) {
        if (buttons[i].panelName == panelName) {
            buttons[i].resetButton();
        }
        if (panelName == "przyciski_stawiania") {
            activeSet = false;
        }
    }
}
